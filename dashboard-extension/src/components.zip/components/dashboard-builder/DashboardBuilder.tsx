/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 *
 * Dashboard designer: build a page from widgets bound to live AIOps queries and from the toolkit's existing
 * panels, arrange it by dragging and resizing, link widgets by clicking, and save it in this browser or as JSON.
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Button, InlineNotification, Select, SelectItem, TextInput } from '@carbon/react';
import { Add, Download, Edit, Redo, Renew, Undo, Upload, View, Copy, TrashCan } from '@carbon/icons-react';
import './dashboard-builder.scss';
import { Dashboard, Filter, QueryName, Widget } from './types';
import { DataHub } from './datahub';
import { BuilderCtx, BuilderContext } from './context';
import { findSpot } from './grid';
import { defaultConfig, defaultTitle, minSize, NATIVE, TILES } from './registry';
import { cloneDashboard, exportJson, importJson, loadState, newId, saveState, sharedDashboard, StoreState } from './store';
import { fieldLabel } from './rows';
import GridCanvas from './GridCanvas';
import Inspector from './Inspector';
import { WidgetBody } from './Widgets';
import { VERSION } from './version';
import { DEFAULT_LAYOUT } from './default-layout';

interface Props {
  /** Tenant for all queries made by the generic widgets. Defaults to the toolkit sample tenant, so set it. */
  tenantId?: string;
  /** Hide all editing. The saved dashboards can still be viewed. */
  readOnly?: boolean;
  /** A published layout (dashboard JSON). Fixed and read-only. */
  layout?: unknown;
  [key: string]: unknown;
}

const MemoBody = React.memo(
  WidgetBody,
  (a, b) => a.w.id === b.w.id && a.w.type === b.w.type && a.w.config === b.w.config
);

interface History {
  past: Widget[][];
  future: Widget[][];
  lastKey?: string;
  lastAt: number;
}

export default function DashboardBuilder(props: Props) {
  // `layout` = a fixed, published layout (from Scaffold Studio): shown read-only, never touches this browser's saved dashboards.
  const fixed = useMemo(() => (props.layout ? sharedDashboard(props.layout) : null), [props.layout]);
  const readOnly = Boolean(props.readOnly) || fixed !== null;
  const [store, setStore] = useState<StoreState>(() =>
    fixed ? { version: 1, activeId: fixed.id, dashboards: [fixed] } : loadState(undefined, sharedDashboard(DEFAULT_LAYOUT)));
  const [editing, setEditing] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [filters, setFilters] = useState<Filter[]>([]);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [notice, setNotice] = useState<{ kind: 'info' | 'error' | 'warning'; text: string } | null>(null);
  const [renaming, setRenaming] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [saveFailed, setSaveFailed] = useState(false);
  const [, setHistoryTick] = useState(0);
  const historyRef = useRef<History>({ past: [], future: [], lastAt: 0 });
  const fileRef = useRef<HTMLInputElement>(null);

  const hub = useMemo(() => new DataHub(undefined, props.tenantId || undefined), [props.tenantId]);

  const active: Dashboard = store.dashboards.find(d => d.id === store.activeId) || store.dashboards[0];
  const selected = active.widgets.find(w => w.id === selectedId) || null;

  // Autosave, debounced. A refused write (private window, full storage) is shown, not swallowed.
  useEffect(() => {
    if (fixed) return undefined; // a published layout is never written to this browser's saved dashboards
    const t = window.setTimeout(() => setSaveFailed(!saveState(store)), 400);
    return () => window.clearTimeout(t);
  }, [store, fixed]);

  const resetHistory = () => { historyRef.current = { past: [], future: [], lastAt: 0 }; setHistoryTick(n => n + 1); };

  // Always points at the latest state, so history bookkeeping happens outside React's state updaters
  // (an updater may run twice in StrictMode and must stay pure).
  const storeRef = useRef(store);
  storeRef.current = store;

  const setWidgets = useCallback((next: Widget[], coalesceKey?: string) => {
    const s = storeRef.current;
    const cur = s.dashboards.find(d => d.id === s.activeId) || s.dashboards[0];
    const h = historyRef.current;
    const now = Date.now();
    // Typing in a field produces many edits; keep them as one undo step.
    const merge = Boolean(coalesceKey) && h.lastKey === coalesceKey && now - h.lastAt < 1200 && h.past.length > 0;
    if (!merge) h.past = [...h.past.slice(-49), cur.widgets];
    h.future = [];
    h.lastKey = coalesceKey;
    h.lastAt = now;
    const id = cur.id;
    setStore(st => ({ ...st, dashboards: st.dashboards.map(d => (d.id === id ? { ...d, widgets: next, updated: now } : d)) }));
    setHistoryTick(n => n + 1);
  }, []);

  const undo = () => {
    const h = historyRef.current;
    if (h.past.length === 0) return;
    const prev = h.past[h.past.length - 1];
    h.past = h.past.slice(0, -1);
    h.future = [active.widgets, ...h.future];
    h.lastKey = undefined;
    setStore(s => ({ ...s, dashboards: s.dashboards.map(d => (d.id === active.id ? { ...d, widgets: prev, updated: Date.now() } : d)) }));
    setHistoryTick(n => n + 1);
  };
  const redo = () => {
    const h = historyRef.current;
    if (h.future.length === 0) return;
    const nxt = h.future[0];
    h.future = h.future.slice(1);
    h.past = [...h.past, active.widgets];
    h.lastKey = undefined;
    setStore(s => ({ ...s, dashboards: s.dashboards.map(d => (d.id === active.id ? { ...d, widgets: nxt, updated: Date.now() } : d)) }));
    setHistoryTick(n => n + 1);
  };

  const toggleFilter = useCallback((from: string, query: QueryName, field: string, value: string) => {
    setFilters(fs => {
      const i = fs.findIndex(f => f.from === from && f.field === field && f.value === value);
      return i >= 0 ? fs.filter((_, j) => j !== i) : [...fs, { from, query, field, value }];
    });
  }, []);

  const ctx: BuilderContext = useMemo(() => ({ hub, filters, toggleFilter }), [hub, filters, toggleFilter]);

  const addWidget = (type: Widget['type'], title?: string, size?: { w: number; h: number }) => {
    const def = NATIVE.find(n => n.type === type);
    const tile = TILES.find(t => `tile:${t.id}` === type);
    const w = size ? size.w : def ? def.w : tile ? tile.w : 4;
    const h = size ? size.h : def ? def.h : tile ? tile.h : 4;
    const spot = findSpot(active.widgets, w, h);
    const widget: Widget = { id: newId('w'), type, title: title || defaultTitle(type), x: spot.x, y: spot.y, w, h, config: defaultConfig(type) };
    setWidgets([...active.widgets, widget]);
    setSelectedId(widget.id);
    setPaletteOpen(false);
  };

  const removeWidget = (id: string) => {
    setWidgets(active.widgets.filter(w => w.id !== id));
    setFilters(fs => fs.filter(f => f.from !== id));
    if (selectedId === id) setSelectedId(null);
  };

  const duplicateWidget = (id: string) => {
    const src = active.widgets.find(w => w.id === id);
    if (!src) return;
    const spot = findSpot(active.widgets, src.w, src.h);
    const copy: Widget = { ...src, id: newId('w'), title: `${src.title} (copy)`, x: spot.x, y: spot.y, config: { ...src.config } };
    setWidgets([...active.widgets, copy]);
    setSelectedId(copy.id);
  };

  const updateWidget = (next: Widget, key: string) => {
    const { minW, minH } = minSize(next.type);
    setWidgets(active.widgets.map(w => (w.id === next.id ? { ...next, w: Math.max(next.w, minW), h: Math.max(next.h, minH) } : w)), key);
    // Changing what a widget is bound to makes its old selections meaningless.
    const old = active.widgets.find(w => w.id === next.id);
    if (old && (old.config.query !== next.config.query || old.config.groupBy !== next.config.groupBy)) {
      setFilters(fs => fs.filter(f => f.from !== next.id));
    }
  };

  /* ── dashboards: switch / new / copy / rename / delete / import / export ── */
  const switchTo = (id: string) => {
    setStore(s => ({ ...s, activeId: id }));
    setSelectedId(null);
    setFilters([]);
    setConfirmDelete(false);
    setRenaming(false);
    resetHistory();
  };

  const newDashboard = () => {
    const d: Dashboard = { id: newId('d'), name: 'New dashboard', updated: Date.now(), widgets: [] };
    setStore(s => ({ ...s, dashboards: [...s.dashboards, d], activeId: d.id }));
    setEditing(true);
    setRenaming(true);
    setSelectedId(null);
    setFilters([]);
    resetHistory();
  };

  const copyDashboard = () => {
    const d = cloneDashboard(active);
    setStore(s => ({ ...s, dashboards: [...s.dashboards, d], activeId: d.id }));
    setSelectedId(null);
    setFilters([]);
    resetHistory();
  };

  const rename = (name: string) => setStore(s => ({ ...s, dashboards: s.dashboards.map(d => (d.id === active.id ? { ...d, name: name.slice(0, 80), updated: Date.now() } : d)) }));

  const deleteDashboard = () => {
    if (store.dashboards.length <= 1) {
      // Never leave the user with nothing: an emptied dashboard replaces the last one.
      const d: Dashboard = { id: newId('d'), name: 'New dashboard', updated: Date.now(), widgets: [] };
      setStore({ ...store, dashboards: [d], activeId: d.id });
    } else {
      const rest = store.dashboards.filter(d => d.id !== active.id);
      setStore({ ...store, dashboards: rest, activeId: rest[0].id });
    }
    setConfirmDelete(false);
    setSelectedId(null);
    setFilters([]);
    resetHistory();
  };

  const doExport = () => {
    try {
      const blob = new Blob([exportJson(active)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${active.name.replace(/[^\w.-]+/g, '-').toLowerCase() || 'dashboard'}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
      setNotice({ kind: 'error', text: 'The browser blocked the download.' });
    }
  };

  const doImport = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const r = importJson(String(reader.result || ''));
      if ('error' in r) {
        setNotice({ kind: 'error', text: r.error });
        return;
      }
      setStore(s => ({ ...s, dashboards: [...s.dashboards, r.dashboard], activeId: r.dashboard.id }));
      setSelectedId(null);
      setFilters([]);
      resetHistory();
      setNotice({
        kind: r.dropped ? 'warning' : 'info',
        text: `Imported “${r.dashboard.name}” (${r.dashboard.widgets.length} widgets).${r.dropped ? ` ${r.dropped} item${r.dropped === 1 ? '' : 's'} could not be used and were left out.` : ''}`
      });
    };
    reader.onerror = () => setNotice({ kind: 'error', text: 'The file could not be read.' });
    reader.readAsText(file);
    if (fileRef.current) fileRef.current.value = '';
  };

  const hasShared = useMemo(() => sharedDashboard(DEFAULT_LAYOUT) !== null, []);
  const addShared = () => {
    const d = sharedDashboard(DEFAULT_LAYOUT);
    if (!d) return;
    setStore(s => ({ ...s, dashboards: [...s.dashboards, d], activeId: d.id }));
    setSelectedId(null);
    setFilters([]);
    resetHistory();
    setNotice({ kind: 'info', text: `Added a copy of the shared layout “${d.name}”.` });
  };

  const refreshAll = () => hub.refresh();
  const h = historyRef.current;
  const isEditing = editing && !readOnly;

  const filterChips = filters.map(f => {
    const from = active.widgets.find(w => w.id === f.from);
    return { f, label: `${fieldLabel(f.query, f.field)}: ${f.value}`, from: from ? from.title : '' };
  });

  const renderBody = useCallback((w: Widget) => <MemoBody w={w} />, []);

  return (
    <BuilderCtx.Provider value={ctx}>
      <div className="dashboard-builder-container">
        <header className="db-bar-top">
          <div className="db-title">
            {renaming && isEditing ? (
              <TextInput
                id="db-rename"
                labelText="Dashboard name"
                hideLabel
                size="sm"
                value={active.name}
                autoFocus
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => rename(e.target.value)}
                onBlur={() => setRenaming(false)}
                onKeyDown={(e: React.KeyboardEvent) => { if (e.key === 'Enter' || e.key === 'Escape') setRenaming(false); }}
              />
            ) : (
              <Select id="db-pick" labelText="Dashboard" hideLabel size="sm" value={active.id} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => switchTo(e.target.value)}>
                {store.dashboards.map(d => <SelectItem key={d.id} value={d.id} text={d.name} />)}
              </Select>
            )}
            <span className="db-version" title="Dashboard Designer version">{VERSION}</span>
          </div>

          <div className="db-tools">
            {isEditing && (
              <>
                <div className="db-palette-wrap">
                  <Button size="sm" kind="primary" renderIcon={Add} onClick={() => setPaletteOpen(o => !o)} aria-expanded={paletteOpen}>Add widget</Button>
                  {paletteOpen && (
                    <div className="db-palette" role="menu">
                      <h4>Data widgets</h4>
                      {NATIVE.map(n => (
                        <button key={n.type} type="button" role="menuitem" className="db-palette-item" onClick={() => addWidget(n.type)}>
                          <strong>{n.label}</strong><span>{n.description}</span>
                        </button>
                      ))}
                      <h4>Existing dashboards</h4>
                      {TILES.map(t => (
                        <button key={t.id} type="button" role="menuitem" className="db-palette-item" onClick={() => addWidget(`tile:${t.id}`, t.label, t)}>
                          <strong>{t.label}</strong><span>{t.description}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <Button size="sm" kind="ghost" hasIconOnly renderIcon={Undo} iconDescription="Undo" tooltipPosition="bottom" disabled={h.past.length === 0} onClick={undo} />
                <Button size="sm" kind="ghost" hasIconOnly renderIcon={Redo} iconDescription="Redo" tooltipPosition="bottom" disabled={h.future.length === 0} onClick={redo} />
                <Button size="sm" kind="ghost" onClick={() => setRenaming(true)}>Rename</Button>
                <Button size="sm" kind="ghost" hasIconOnly renderIcon={Copy} iconDescription="Duplicate dashboard" tooltipPosition="bottom" onClick={copyDashboard} />
                {confirmDelete ? (
                  <span className="db-confirm">
                    Delete “{active.name}”?
                    <Button size="sm" kind="danger" onClick={deleteDashboard}>Delete</Button>
                    <Button size="sm" kind="ghost" onClick={() => setConfirmDelete(false)}>Keep</Button>
                  </span>
                ) : (
                  <Button size="sm" kind="ghost" hasIconOnly renderIcon={TrashCan} iconDescription="Delete dashboard" tooltipPosition="bottom" onClick={() => setConfirmDelete(true)} />
                )}
                <span className="db-sep" />
              </>
            )}
            {!readOnly && <Button size="sm" kind="ghost" renderIcon={Add} onClick={newDashboard}>New</Button>}
            <Button size="sm" kind="ghost" renderIcon={Download} onClick={doExport}>Export</Button>
            {!readOnly && <Button size="sm" kind="ghost" renderIcon={Upload} onClick={() => fileRef.current && fileRef.current.click()}>Import</Button>}
            <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={e => doImport(e.target.files ? e.target.files[0] : undefined)} />
            {!readOnly && hasShared && <Button size="sm" kind="ghost" renderIcon={Copy} onClick={addShared}>Shared layout</Button>}
            <Button size="sm" kind="ghost" renderIcon={Renew} onClick={refreshAll}>Refresh</Button>
            {!readOnly && (
              <Button size="sm" kind={isEditing ? 'secondary' : 'tertiary'} renderIcon={isEditing ? View : Edit} onClick={() => { setEditing(e => !e); setPaletteOpen(false); setSelectedId(null); }}>
                {isEditing ? 'Done' : 'Edit'}
              </Button>
            )}
          </div>
        </header>

        {saveFailed && (
          <InlineNotification
            kind="warning"
            lowContrast
            hideCloseButton
            title="Not saved in this browser."
            subtitle="Storage is blocked or full. Use Export to keep your work."
          />
        )}
        {notice && (
          <InlineNotification kind={notice.kind} lowContrast title={notice.text} onCloseButtonClick={() => setNotice(null)} />
        )}

        {filterChips.length > 0 && (
          <div className="db-filters" role="status" aria-label="Active filters">
            <span>Filtering by</span>
            {filterChips.map(({ f, label, from }) => (
              <button key={`${f.from}-${f.field}-${f.value}`} type="button" className="db-chip" title={from ? `Set from ${from}. Click to remove.` : 'Click to remove'} onClick={() => toggleFilter(f.from, f.query, f.field, f.value)}>
                {label} ×
              </button>
            ))}
            <button type="button" className="db-link" onClick={() => setFilters([])}>Clear all</button>
          </div>
        )}

        <div className={`db-main${isEditing && selected ? ' with-inspector' : ''}`}>
          <div className="db-stage">
            <GridCanvas
              widgets={active.widgets}
              rowH={active.rowH}
              editing={isEditing}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onLayout={next => setWidgets(next)}
              onRemove={removeWidget}
              onDuplicate={duplicateWidget}
              renderBody={renderBody}
            />
          </div>
          {isEditing && selected && (
            <Inspector widget={selected} onChange={updateWidget} onClose={() => setSelectedId(null)} />
          )}
        </div>
      </div>
    </BuilderCtx.Provider>
  );
}
