/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 *
 * Saved dashboards. They live in this browser's localStorage and move between browsers as a JSON file.
 * Everything read back is validated and clamped, so a hand-edited or old file cannot break the page.
 */

import { COND_OPS, Cond, CondOp, Dashboard, GRID_COLS, QueryName, Widget, WidgetConfig } from './types';
import { clampBox, compact } from './grid';
import { defaultConfig, isKnownType, minSize } from './registry';
import { isImageSrc } from './image';

export const STORE_KEY = 'dashboard-builder:v1';
export const FILE_KIND = 'dashboard-builder';

export interface StoreState {
  version: 1;
  activeId: string;
  dashboards: Dashboard[];
}

export interface KV {
  getItem(k: string): string | null;
  setItem(k: string, v: string): void;
}

let counter = 0;
export function newId(prefix: string): string {
  counter += 1;
  return `${prefix}-${Date.now().toString(36)}${counter.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

function widget(type: Widget['type'], title: string, x: number, y: number, w: number, h: number, cfg: Partial<WidgetConfig> & { query: QueryName }): Widget {
  return { id: newId('w'), type, title, x, y, w, h, config: { ...defaultConfig(type, cfg.query), ...cfg } };
}

/** A starting point built only from live-bound widgets: every figure comes from the queries. */
export function starterDashboard(): Dashboard {
  return {
    id: newId('d'),
    name: 'Operations overview',
    updated: Date.now(),
    widgets: [
      widget('kpi', 'Open alerts', 0, 0, 3, 3, { query: 'getAlerts', metric: 'count' }),
      widget('kpi', 'Critical alerts', 3, 0, 3, 3, { query: 'getAlerts', metric: 'count', where: { field: 'severityLabel', value: 'Critical' } }),
      widget('kpi', 'Incidents', 6, 0, 3, 3, { query: 'getStories', metric: 'count' }),
      widget('kpi', 'Affected resources', 9, 0, 3, 3, { query: 'getAlerts', metric: 'distinct', valueField: 'resource' }),
      widget('bar', 'Alerts by severity', 0, 3, 4, 6, { query: 'getAlerts', groupBy: 'severityLabel' }),
      widget('donut', 'Alerts by state', 4, 3, 4, 6, { query: 'getAlerts', groupBy: 'state' }),
      widget('bar', 'Top resources', 8, 3, 4, 6, { query: 'getAlerts', groupBy: 'resource', limit: 8 }),
      widget('timeseries', 'Alerts over time', 0, 9, 12, 5, { query: 'getAlerts', timeField: 'firstOccurrence' }),
      widget('table', 'Alerts', 0, 14, 12, 8, { query: 'getAlerts' })
    ]
  };
}

function isObj(v: unknown): v is Record<string, any> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function str(v: unknown, fallback: string, max = 200): string {
  return typeof v === 'string' && v.trim() ? v.slice(0, max) : fallback;
}

function numOr(v: unknown): number | undefined {
  const n = Number(v);
  return v !== null && v !== '' && Number.isFinite(n) ? n : undefined;
}

/** Flat options for a tile: at most 8 short names with string / number / boolean values. Anything else is dropped. */
export function sanitizeTileProps(raw: unknown): Record<string, string | number | boolean> | undefined {
  if (!isObj(raw)) return undefined;
  const out: Record<string, string | number | boolean> = {};
  let n = 0;
  for (const key of Object.keys(raw)) {
    if (n >= 8) break;
    if (!/^[A-Za-z][A-Za-z0-9]{0,31}$/.test(key) || key === 'constructor' || key === 'prototype') continue;
    const v = (raw as Record<string, unknown>)[key];
    if (typeof v === 'string') out[key] = v.slice(0, 100);
    else if (typeof v === 'number' && Number.isFinite(v)) out[key] = v;
    else if (typeof v === 'boolean') out[key] = v;
    else continue;
    n += 1;
  }
  return n > 0 ? out : undefined;
}

export function sanitizeConfig(raw: unknown, type: Widget['type']): WidgetConfig {
  const r = isObj(raw) ? raw : {};
  const query: QueryName = r.query === 'getStories' ? 'getStories' : 'getAlerts';
  const base = defaultConfig(type, query);
  const cfg: WidgetConfig = { ...base, query };
  if (typeof r.filter === 'string') cfg.filter = r.filter.slice(0, 500);
  if (typeof r.groupBy === 'string') cfg.groupBy = r.groupBy.slice(0, 80);
  if (typeof r.valueField === 'string') cfg.valueField = r.valueField.slice(0, 80);
  if (typeof r.timeField === 'string') cfg.timeField = r.timeField.slice(0, 80);
  if (typeof r.sortBy === 'string') cfg.sortBy = r.sortBy.slice(0, 80);
  if (typeof r.sortDesc === 'boolean') cfg.sortDesc = r.sortDesc;
  if (r.overlay === true) cfg.overlay = true;
  if (typeof r.text === 'string') cfg.text = r.text.slice(0, 2000);
  if (typeof r.part === 'string') cfg.part = r.part.slice(0, 200);
  if (type.startsWith('tile:')) {
    const props = sanitizeTileProps(r.props);
    if (props) cfg.props = props;
    if (typeof r.chromeless === 'boolean') cfg.chromeless = r.chromeless;
  }
  if (type === 'image') {
    if (isImageSrc(r.src)) cfg.src = r.src;
    if (typeof r.alt === 'string') cfg.alt = r.alt.slice(0, 200);
    if (r.fit === 'cover' || r.fit === 'fill' || r.fit === 'contain') cfg.fit = r.fit;
  }
  if (['count', 'distinct', 'max', 'avg', 'sum'].includes(r.metric)) cfg.metric = r.metric;
  if (Array.isArray(r.columns)) cfg.columns = r.columns.filter((c: unknown) => typeof c === 'string').slice(0, 12);
  const limit = numOr(r.limit);
  if (limit !== undefined) cfg.limit = Math.min(Math.max(Math.round(limit), 1), 500);
  const refresh = numOr(r.refreshSeconds);
  if (refresh !== undefined) cfg.refreshSeconds = refresh <= 0 ? 0 : Math.min(Math.max(Math.round(refresh), 10), 3600);
  if (typeof r.emits === 'boolean') cfg.emits = r.emits;
  if (typeof r.listens === 'boolean') cfg.listens = r.listens;
  const cond = (x: any): Cond | undefined => (isObj(x) && typeof x.field === 'string' && typeof x.value === 'string'
    ? { field: x.field.slice(0, 80), value: x.value.slice(0, 200), ...(COND_OPS.includes(x.op) && x.op !== '=' ? { op: x.op as CondOp } : {}) }
    : undefined);
  const w1 = cond(r.where);
  if (w1) cfg.where = w1;
  if (Array.isArray(r.also)) {
    const more = r.also.map(cond).filter((x: Cond | undefined): x is Cond => !!x).slice(0, 8);
    if (more.length) cfg.also = more;
  }
  return cfg;
}

/** Returns a clean dashboard and how many widgets had to be dropped (unknown type, not an object). */
export function sanitizeDashboard(raw: unknown): { dashboard: Dashboard; dropped: number } | null {
  if (!isObj(raw) || !Array.isArray(raw.widgets)) return null;
  let dropped = 0;
  const widgets: Widget[] = [];
  const seen = new Set<string>();
  raw.widgets.forEach((w: unknown) => {
    if (!isObj(w) || typeof w.type !== 'string' || !isKnownType(w.type)) {
      dropped++;
      return;
    }
    const type = w.type;
    let id = typeof w.id === 'string' && w.id ? w.id : newId('w');
    if (seen.has(id)) id = newId('w');
    seen.add(id);
    const { minW, minH } = minSize(type);
    const box = clampBox({ id, x: Number(w.x) || 0, y: Number(w.y) || 0, w: Number(w.w) || 4, h: Number(w.h) || 4 }, minW, minH);
    widgets.push({
      id,
      type,
      title: str(w.title, 'Widget', 120),
      x: box.x,
      y: box.y,
      w: box.w,
      h: box.h,
      config: sanitizeConfig(w.config, type)
    });
  });
  const laid = compact(widgets);
  return {
    dashboard: { id: str(raw.id, newId('d'), 80), name: str(raw.name, 'Imported dashboard', 80), updated: Date.now(), widgets: laid, ...(Number.isFinite(Number(raw.rowH)) && Number(raw.rowH) > 0 ? { rowH: Math.min(Math.max(Math.round(Number(raw.rowH)), 24), 96) } : {}) },
    dropped
  };
}

export function loadState(storage?: KV, seed?: Dashboard | null): StoreState {
  try {
    const kv = storage || (typeof localStorage !== 'undefined' ? localStorage : undefined);
    const text = kv ? kv.getItem(STORE_KEY) : null;
    if (text) {
      const parsed = JSON.parse(text);
      if (isObj(parsed) && Array.isArray(parsed.dashboards)) {
        const dashboards: Dashboard[] = [];
        parsed.dashboards.forEach((d: unknown) => {
          const s = sanitizeDashboard(d);
          if (s) dashboards.push({ ...s.dashboard, updated: isObj(d) && Number.isFinite(Number(d.updated)) ? Number(d.updated) : s.dashboard.updated });
        });
        if (dashboards.length > 0) {
          const active = dashboards.some(d => d.id === parsed.activeId) ? parsed.activeId : dashboards[0].id;
          return { version: 1, activeId: active, dashboards };
        }
      }
    }
  } catch (e) {
    // Fall through to a fresh state: unreadable storage must never block the page.
  }
  // First visit in this browser: start from the shared layout when there is one.
  const starter = seed || starterDashboard();
  return { version: 1, activeId: starter.id, dashboards: [starter] };
}

/** The layout shipped with the bundle (from Scaffold Studio), cleaned and given fresh ids; null when there is none. */
export function sharedDashboard(raw: unknown): Dashboard | null {
  if (raw === null || raw === undefined) return null;
  const body = isObj(raw) && raw.kind === FILE_KIND ? raw.dashboard : raw;
  const s = sanitizeDashboard(body);
  if (!s || s.dashboard.widgets.length === 0) return null;
  return { ...s.dashboard, id: newId('d'), widgets: s.dashboard.widgets.map(w => ({ ...w, id: newId('w') })) };
}

/** Returns false when the browser refused the write (private mode, quota). */
export function saveState(state: StoreState, storage?: KV): boolean {
  try {
    const kv = storage || (typeof localStorage !== 'undefined' ? localStorage : undefined);
    if (!kv) return false;
    kv.setItem(STORE_KEY, JSON.stringify(state));
    return true;
  } catch (e) {
    return false;
  }
}

export function exportJson(d: Dashboard): string {
  return JSON.stringify({ kind: FILE_KIND, version: 1, dashboard: d }, null, 2);
}

export function importJson(text: string): { dashboard: Dashboard; dropped: number } | { error: string } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch (e) {
    return { error: 'That file is not valid JSON.' };
  }
  const body = isObj(parsed) && parsed.kind === FILE_KIND ? parsed.dashboard : parsed;
  const s = sanitizeDashboard(body);
  if (!s) return { error: 'That file does not look like a dashboard exported from this builder.' };
  // Fresh ids so an import never overwrites a dashboard that is already saved.
  return { dashboard: { ...s.dashboard, id: newId('d') }, dropped: s.dropped };
}

export function cloneDashboard(d: Dashboard, name?: string): Dashboard {
  return {
    ...d,
    id: newId('d'),
    name: name || `${d.name} (copy)`,
    updated: Date.now(),
    widgets: d.widgets.map(w => ({ ...w, id: newId('w'), config: { ...w.config } }))
  };
}

export { GRID_COLS };
