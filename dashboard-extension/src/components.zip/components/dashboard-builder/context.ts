/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DataHub } from './datahub';
import { Filter, QueryName } from './types';

export interface BuilderContext {
  hub: DataHub;
  filters: Filter[];
  toggleFilter: (from: string, query: QueryName, field: string, value: string) => void;
}

export const BuilderCtx = React.createContext<BuilderContext | null>(null);

export function useBuilder(): BuilderContext {
  const ctx = React.useContext(BuilderCtx);
  if (!ctx) throw new Error('Widgets must be rendered inside the dashboard builder.');
  return ctx;
}
