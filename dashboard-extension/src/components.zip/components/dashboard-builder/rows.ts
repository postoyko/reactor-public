/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 *
 * Turns query responses into flat rows and aggregates them. Nothing is invented: a field that is missing stays
 * undefined and is shown as "(none)".
 */

import { Metric, QueryName, Row } from './types';

export const SEVERITY_LABELS = ['Clear', 'Indeterminate', 'Information', 'Warning', 'Minor', 'Major', 'Critical'];
/** Carbon-ish colours, indexed by severity number 0..6 (same order as SEVERITY_LABELS). */
export const SEVERITY_COLORS = ['#8d8d8d', '#a56eff', '#78a9ff', '#4589ff', '#f1c21b', '#ff832b', '#da1e28'];

/** Alert columns requested for the generic widgets (all of them already used by the toolkit's own queries). */
export const ALERT_COLUMNS = [
  'id', 'severity', 'state', 'summary', 'type.classification', 'sender.name', 'resource.name',
  'firstOccurrenceTime', 'lastOccurrenceTime', 'closedTime', 'owner', 'team', 'acknowledged', 'suppressed'
];

const ALERT_FIELD_MAP: Array<[string, string]> = [
  ['id', 'id'], ['severity', 'severity'], ['state', 'state'], ['summary', 'summary'],
  ['type.classification', 'type'], ['sender.name', 'sender'], ['resource.name', 'resource'],
  ['firstOccurrenceTime', 'firstOccurrence'], ['lastOccurrenceTime', 'lastOccurrence'], ['closedTime', 'closed'],
  ['owner', 'owner'], ['team', 'team'], ['acknowledged', 'acknowledged'], ['suppressed', 'suppressed']
];

export interface FieldInfo {
  key: string;
  label: string;
  kind: 'text' | 'number' | 'time';
}

export const FIELDS: Record<QueryName, FieldInfo[]> = {
  getAlerts: [
    { key: 'severityLabel', label: 'Severity', kind: 'text' },
    { key: 'severity', label: 'Severity (number)', kind: 'number' },
    { key: 'state', label: 'State', kind: 'text' },
    { key: 'resource', label: 'Resource', kind: 'text' },
    { key: 'sender', label: 'Source (sender)', kind: 'text' },
    { key: 'type', label: 'Type', kind: 'text' },
    { key: 'team', label: 'Team', kind: 'text' },
    { key: 'owner', label: 'Owner', kind: 'text' },
    { key: 'acknowledged', label: 'Acknowledged', kind: 'text' },
    { key: 'summary', label: 'Summary', kind: 'text' },
    { key: 'firstOccurrence', label: 'First occurrence', kind: 'time' },
    { key: 'lastOccurrence', label: 'Last occurrence', kind: 'time' },
    { key: 'id', label: 'Alert id', kind: 'text' }
  ],
  getStories: [
    { key: 'priority', label: 'Priority', kind: 'number' },
    { key: 'state', label: 'State', kind: 'text' },
    { key: 'team', label: 'Team', kind: 'text' },
    { key: 'owner', label: 'Owner', kind: 'text' },
    { key: 'title', label: 'Title', kind: 'text' },
    { key: 'description', label: 'Description', kind: 'text' },
    { key: 'alertCount', label: 'Alert count', kind: 'number' },
    { key: 'created', label: 'Created', kind: 'time' },
    { key: 'id', label: 'Incident id', kind: 'text' }
  ]
};

export const DEFAULT_GROUP: Record<QueryName, string> = { getAlerts: 'severityLabel', getStories: 'priority' };
export const DEFAULT_TIME: Record<QueryName, string> = { getAlerts: 'firstOccurrence', getStories: 'created' };

export function fieldsOf(query: QueryName, kind?: FieldInfo['kind']): FieldInfo[] {
  return FIELDS[query].filter(f => !kind || f.kind === kind);
}

export function fieldLabel(query: QueryName, key: string): string {
  const f = FIELDS[query].find(x => x.key === key);
  return f ? f.label : key;
}

function clean(v: unknown): string | undefined {
  return v === null || v === undefined || v === '' ? undefined : String(v);
}

/** getAlerts response (`data.tenant.alerts.{columns,rows}`) -> rows. */
export function alertRows(data: any): Row[] {
  const src = data?.tenant?.alerts;
  const columns: Array<{ name?: string }> = Array.isArray(src?.columns) ? src.columns : [];
  const raw: Array<{ fields?: Array<string | null> }> = Array.isArray(src?.rows) ? src.rows : [];
  const index = new Map<string, number>();
  columns.forEach((c, i) => { if (c && c.name) index.set(c.name, i); });
  const out: Row[] = [];
  raw.forEach(r => {
    const f = (r && r.fields) || [];
    const row: Row = {};
    ALERT_FIELD_MAP.forEach(([col, key]) => {
      const i = index.get(col);
      const v = i === undefined ? undefined : clean(f[i]);
      if (v !== undefined) row[key] = key === 'severity' ? Number(v) : v;
    });
    if (row.id === undefined) return;
    if (typeof row.severity === 'number' && !Number.isFinite(row.severity)) delete row.severity;
    if (typeof row.severity === 'number') row.severityLabel = SEVERITY_LABELS[row.severity] || `Severity ${row.severity}`;
    out.push(row);
  });
  return out;
}

/** getStories response (`data.tenant.stories`, optionally `.stories`) -> rows. */
export function incidentRows(data: any): Row[] {
  const raw = data?.tenant?.stories;
  const list: any[] = Array.isArray(raw) ? raw : Array.isArray(raw?.stories) ? raw.stories : [];
  const out: Row[] = [];
  list.forEach(s => {
    if (!s || typeof s !== 'object' || !s.id) return;
    const row: Row = { id: String(s.id) };
    const pr = Number(s.priority);
    if (s.priority !== null && s.priority !== undefined && Number.isFinite(pr)) row.priority = pr;
    (['state', 'team', 'owner', 'title', 'description'] as const).forEach(k => {
      const v = clean(s[k]);
      if (v !== undefined) row[k] = v;
    });
    const created = clean(s.createdTime);
    if (created !== undefined) row.created = created;
    if (Array.isArray(s.alertIds)) row.alertCount = s.alertIds.length;
    out.push(row);
  });
  return out;
}

export function toRows(query: QueryName, data: any): Row[] {
  return query === 'getAlerts' ? alertRows(data) : incidentRows(data);
}

export const NONE = '(none)';

export function cell(row: Row, key: string): string {
  const v = row[key];
  return v === undefined ? NONE : String(v);
}

export interface Bucket {
  key: string;
  value: number;
}

function num(row: Row, key: string): number | undefined {
  const v = row[key];
  const n = typeof v === 'number' ? v : v === undefined ? NaN : Number(v);
  return Number.isFinite(n) ? n : undefined;
}

/** One number over all rows, or undefined when it cannot be computed (no numeric values). */
export function metricValue(rows: Row[], metric: Metric, field?: string): number | undefined {
  if (metric === 'count') return rows.length;
  if (!field) return undefined;
  if (metric === 'distinct') {
    const s = new Set<string>();
    rows.forEach(r => { if (r[field] !== undefined) s.add(String(r[field])); });
    return s.size;
  }
  const vals = rows.map(r => num(r, field)).filter((v): v is number => v !== undefined);
  if (vals.length === 0) return undefined;
  if (metric === 'max') return Math.max(...vals);
  const sum = vals.reduce((a, b) => a + b, 0);
  return metric === 'sum' ? sum : sum / vals.length;
}

/** Group rows by a field and compute a metric per group. Sorted by value, then label. */
export function groupMetric(rows: Row[], groupBy: string, metric: Metric = 'count', field?: string, limit = 12): Bucket[] {
  const groups = new Map<string, Row[]>();
  rows.forEach(r => {
    const k = cell(r, groupBy);
    const g = groups.get(k);
    if (g) g.push(r); else groups.set(k, [r]);
  });
  const out: Bucket[] = [];
  groups.forEach((g, key) => {
    const v = metricValue(g, metric, field);
    if (v !== undefined) out.push({ key, value: v });
  });
  out.sort((a, b) => b.value - a.value || a.key.localeCompare(b.key));
  if (out.length <= limit) return out;
  const head = out.slice(0, Math.max(limit - 1, 1));
  const tail = out.slice(head.length);
  if (metric === 'count' || metric === 'sum') head.push({ key: `Other (${tail.length})`, value: tail.reduce((a, b) => a + b.value, 0) });
  return head;
}

/** Severity groups keep their natural order (Critical first) and colours. */
export function orderSeverity(buckets: Bucket[]): Bucket[] {
  const rank = (k: string) => {
    const i = SEVERITY_LABELS.indexOf(k);
    return i < 0 ? -1 : i;
  };
  return buckets.slice().sort((a, b) => rank(b.key) - rank(a.key));
}

export interface TimeBin {
  start: number;
  end: number;
  value: number;
}

/** Count rows per time bin. Rows without a parseable time are counted separately, not dropped silently. */
export function timeBins(rows: Row[], field: string, bins = 24): { bins: TimeBin[]; missing: number } {
  const times: number[] = [];
  let missing = 0;
  rows.forEach(r => {
    const raw = r[field];
    const t = raw === undefined ? NaN : typeof raw === 'number' ? raw : Date.parse(String(raw));
    if (Number.isFinite(t)) times.push(t); else missing++;
  });
  if (times.length === 0) return { bins: [], missing };
  const lo = Math.min(...times);
  const hi = Math.max(...times);
  if (hi === lo) return { bins: [{ start: lo - 30000, end: hi + 30000, value: times.length }], missing };
  const step = (hi - lo) / bins;
  const out: TimeBin[] = Array.from({ length: bins }, (_, i) => ({ start: lo + i * step, end: lo + (i + 1) * step, value: 0 }));
  times.forEach(t => { out[Math.min(Math.floor((t - lo) / step), bins - 1)].value++; });
  return { bins: out, missing };
}

export function applyFilters(rows: Row[], filters: Array<{ field: string; value: string }>): Row[] {
  if (filters.length === 0) return rows;
  // Several values for the same field are alternatives (OR); different fields must all match (AND).
  const byField = new Map<string, Set<string>>();
  filters.forEach(f => {
    const s = byField.get(f.field);
    if (s) s.add(f.value); else byField.set(f.field, new Set([f.value]));
  });
  return rows.filter(r => {
    let ok = true;
    byField.forEach((vals, field) => { if (!vals.has(cell(r, field))) ok = false; });
    return ok;
  });
}

export function formatNumber(n: number): string {
  if (Math.abs(n) >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (Math.abs(n) >= 10000) return `${(n / 1000).toFixed(1)}k`;
  return Number.isInteger(n) ? String(n) : n.toFixed(1);
}
