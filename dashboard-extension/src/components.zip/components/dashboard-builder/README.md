# Dashboard Designer

A page where people build their own dashboards inside Concert Operate / Cloud Pak for AIOps: add widgets, bind them to
live queries, drag and resize them, link them so a click in one filters the others, and save the result.

## What a user can do

| Action | How |
| --- | --- |
| Add a widget | **Edit** → **Add widget** → pick one. It lands in the first free space. |
| Move / resize | Drag the title bar; drag the corner. Others are pushed down and the page floats up, so nothing overlaps. Keyboard: select a widget, arrows move, Shift+arrows resize, Delete removes. |
| Bind to data | Select a widget → **Settings**: source (alerts or incidents), an optional alert filter, an optional "only rows where field = value", the field to group or measure, refresh interval. |
| Link widgets | Click a bar or donut slice: other widgets on the same source follow. Click again, or a chip above the grid, to clear. Each widget has *Click sets a filter* and *Follows filters* switches. |
| Undo / redo | Buttons in the bar (last 50 steps; typing in one field counts as one step). |
| Several dashboards | Pick from the list; **New**, **Duplicate**, **Rename**, **Delete**. |
| Save / share | Saved automatically in this browser. **Export** downloads a JSON file; **Import** loads one (as a new dashboard). |

## Widgets

Data widgets (all computed from the loaded rows, nothing invented):

| Widget | Shows |
| --- | --- |
| Number | Count, distinct count, max, average or sum of a field, optionally for rows matching a condition. Shows **n/a** when a field has no numeric values. |
| Bar chart / Donut | Rows grouped by a field (severity, state, resource, team, …), top N plus "Other". Click to filter. |
| Timeline | Rows counted over a time field. Rows with no time are counted in a note, not dropped silently. |
| Table | Chosen columns, sortable, row limit. |
| Note | Free text. |

**Existing dashboards as tiles:** Telco Causal Mesh (Gen 2 and original), Telco Command Center, Incident & Alert Dashboard,
Cognitive Deep Dive, Top N, Heatmap, Pie chart, Monitor boxes, Alerts workflow.
A tile is the existing panel unchanged. It fetches its own data and does **not** take part in linking. Give big ones room
(the Gen 2 mesh wants roughly 8 × 14 cells or more).

## Data and honesty

* Alerts come from `getAlerts`, incidents from `getStories`: the same queries and tenant constant the other dashboards use
  (`ALERT_QUERY_PARAMS.tenantId` in `src/components/constants.ts`).
* One request per distinct source and filter is shared by every widget that uses it; a failed refresh keeps the last result
  on screen with a notice.
* A missing field is shown as **(none)** or **n/a**, never as zero or a guess.
* The *Alert filter* box is sent to the server unchanged. Its syntax has **not** been verified against a cluster from here;
  the *Only rows where* condition is applied in the browser and always works.
* Linking works between widgets on the same source (alerts with alerts, incidents with incidents). It is exact-match on one field.
* The Operations overview dashboard that appears on first use is built only from live-bound widgets.

## Files

| File | Purpose |
| --- | --- |
| `DashboardBuilder.tsx` | The page: toolbar, dashboards, undo, import/export, filter chips |
| `GridCanvas.tsx` | 12-column drag / resize / keyboard surface |
| `Widgets.tsx`, `Tiles.tsx` | Data widgets and the embedded existing panels |
| `Inspector.tsx` | Settings for the selected widget |
| `grid.ts` | Pure layout rules (collision, push-down, float-up) |
| `rows.ts` | Query response → rows; grouping, measures, time bins, filters |
| `datahub.ts` | Shared, de-duplicated, refreshable queries |
| `store.ts` | Saved dashboards, validation of anything read back, JSON import/export, starter dashboard |
| `registry.ts`, `types.ts`, `context.ts`, `version.ts` | Widget catalogue and shared types |
| `dashboard-builder.panel.ts` | Panel (goes in `src/panels/`) |
| `logic.test.ts` | 25 tests for the pure files |

## Not included (yet)

* Saved dashboards are per browser. Sharing is by JSON file. A shared store would need a backend or cluster write path.
* Tiles do not take part in linking, and widgets do not link across different sources.
* No per-user permissions, no scheduled export, no free-form SQL or custom queries (only `getAlerts` and `getStories`).
* The panel options `tenantId` and `readOnly` exist, but this toolkit version does not pass route state to panels, so they only matter if you wrap the panel yourself.

## Checked, and not checked

Checked here: strict and loose (`strictNullChecks` off) TypeScript, 25 unit tests, SCSS compile, and a scripted jsdom run
(mount, live-bound numbers, cross-filtering, add / drag / keyboard move / undo / redo / delete, import with a bad item,
read-only mode, autosave). **Not** checked: real Carbon components and styling, a real browser's pointer and layout
behaviour, touch input, the embedded tiles inside the grid, and a real cluster response. Treat the first deploy as the test.
