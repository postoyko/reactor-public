/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 *
 * One fetch per distinct (query, filter), shared by every widget that asks for it. Refreshes on the shortest
 * interval any subscriber asked for. Responses that arrive out of order are ignored.
 */

import { ALERT_QUERY_PARAMS, INCIDENT_QUERY_PARAMS } from '../constants';
import { QueryName, Row } from './types';
import { ALERT_COLUMNS, toRows } from './rows';

export type Fetcher = (query: QueryName, params: Record<string, unknown>) => Promise<any>;

export interface SourceState {
  rows: Row[];
  loading: boolean;
  error?: string;
  updated?: number;
}

const EMPTY: SourceState = { rows: [], loading: false };

interface Entry {
  query: QueryName;
  filter: string;
  state: SourceState;
  subs: Map<number, { refresh: number; fn: () => void }>;
  timer?: ReturnType<typeof setInterval>;
  timerMs: number;
  seq: number;
  started: boolean;
}

export function sourceKey(query: QueryName, filter?: string): string {
  return `${query}|${(filter || '').trim()}`;
}

export function defaultFetcher(query: QueryName, params: Record<string, unknown>): Promise<any> {
  const fn = (window as any).akoraConfig?.baseState?.API?.contentAnalyticsAPI?.[query];
  if (typeof fn !== 'function') return Promise.reject(new Error(`The ${query} query is not available in this environment.`));
  return fn(params);
}

export class DataHub {
  private entries = new Map<string, Entry>();
  private nextSub = 1;

  constructor(private fetcher: Fetcher = defaultFetcher, private tenantId: string = ALERT_QUERY_PARAMS.tenantId) {}

  paramsFor(query: QueryName, filter: string): Record<string, unknown> {
    if (query === 'getAlerts') {
      return { tenantId: this.tenantId, columns: ALERT_COLUMNS, filter: filter || ALERT_QUERY_PARAMS.filter, format: ALERT_QUERY_PARAMS.format };
    }
    return { ...INCIDENT_QUERY_PARAMS, tenantId: this.tenantId };
  }

  snapshot(key: string): SourceState {
    const e = this.entries.get(key);
    return e ? e.state : EMPTY;
  }

  /** Start using a source. Returns a function that stops using it. */
  acquire(query: QueryName, filter: string | undefined, refreshSeconds: number, onChange: () => void): () => void {
    const key = sourceKey(query, filter);
    let e = this.entries.get(key);
    if (!e) {
      e = { query, filter: (filter || '').trim(), state: { rows: [], loading: false }, subs: new Map(), timerMs: 0, seq: 0, started: false };
      this.entries.set(key, e);
    }
    const id = this.nextSub++;
    e.subs.set(id, { refresh: refreshSeconds > 0 ? refreshSeconds : 0, fn: onChange });
    this.retime(e);
    if (!e.started) {
      e.started = true;
      this.load(key);
    }
    return () => {
      const cur = this.entries.get(key);
      if (!cur) return;
      cur.subs.delete(id);
      this.retime(cur);
      if (cur.subs.size === 0) {
        if (cur.timer) clearInterval(cur.timer);
        cur.seq++; // anything still in flight is stale
        this.entries.delete(key);
      }
    };
  }

  refresh(key?: string) {
    if (key) { this.load(key); return; }
    Array.from(this.entries.keys()).forEach(k => this.load(k));
  }

  private retime(e: Entry) {
    const wanted = Array.from(e.subs.values()).map(s => s.refresh).filter(r => r > 0);
    const ms = wanted.length ? Math.min(...wanted) * 1000 : 0;
    if (ms === e.timerMs) return;
    if (e.timer) clearInterval(e.timer);
    e.timer = undefined;
    e.timerMs = ms;
    if (ms > 0) e.timer = setInterval(() => this.load(sourceKey(e.query, e.filter)), ms);
  }

  private notify(e: Entry) {
    Array.from(e.subs.values()).forEach(s => s.fn());
  }

  private load(key: string) {
    const e = this.entries.get(key);
    if (!e) return;
    const seq = ++e.seq;
    e.state = { ...e.state, loading: true };
    this.notify(e);
    let p: Promise<any>;
    try {
      p = this.fetcher(e.query, this.paramsFor(e.query, e.filter));
    } catch (err) {
      p = Promise.reject(err);
    }
    p.then(
      data => {
        if (e.seq !== seq) return;
        e.state = { rows: toRows(e.query, data), loading: false, updated: Date.now() };
        this.notify(e);
      },
      err => {
        if (e.seq !== seq) return;
        const msg = err && err.message ? String(err.message) : 'The query failed.';
        // Keep the last good rows on screen next to the error rather than blanking the widget.
        e.state = { rows: e.state.rows, loading: false, error: msg, updated: e.state.updated };
        this.notify(e);
      }
    );
  }
}
