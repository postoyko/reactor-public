/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 *
 * Settings for the selected widget: what it is bound to (query, filter, field), how it is drawn, how often it
 * refreshes, and whether it takes part in cross-filtering.
 */

import React from 'react';
import { Button, Checkbox, Select, SelectItem, TextInput, Toggle } from '@carbon/react';
import { Close } from '@carbon/icons-react';
import { COND_OPS, CondOp, Cond, Metric, QueryName, Widget, WidgetConfig } from './types';
import { DEFAULT_GROUP, DEFAULT_TIME, fieldLabel, fieldsOf } from './rows';
import { isNative, tileDef } from './registry';
import { describeImageError, IMAGE_ACCEPT, IMAGE_MAX_BYTES, imageMimeOk, isImageSrc } from './image';

interface Props {
  widget: Widget;
  onChange: (next: Widget, coalesceKey: string) => void;
  onClose: () => void;
}

const REFRESH = [
  { v: 0, t: 'Off (use Refresh)' },
  { v: 15, t: 'Every 15 seconds' },
  { v: 30, t: 'Every 30 seconds' },
  { v: 60, t: 'Every minute' },
  { v: 300, t: 'Every 5 minutes' }
];

const METRICS: Array<{ v: Metric; t: string }> = [
  { v: 'count', t: 'Count of rows' },
  { v: 'distinct', t: 'Distinct values of…' },
  { v: 'max', t: 'Highest value of…' },
  { v: 'avg', t: 'Average of…' },
  { v: 'sum', t: 'Sum of…' }
];

export default function Inspector({ widget, onChange, onClose }: Props) {
  const [imageError, setImageError] = React.useState('');
  const c = widget.config;
  const t = widget.type;
  const id = (s: string) => `db-${widget.id}-${s}`;
  const setCfg = (patch: Partial<WidgetConfig>, key: string) => onChange({ ...widget, config: { ...c, ...patch } }, `${widget.id}:${key}`);
  const setQuery = (q: QueryName) => {
    if (q === c.query) return;
    // Field names differ between alerts and incidents, so anything bound to a field is reset to a valid default.
    setCfg({
      query: q,
      where: undefined,
      also: undefined,
      groupBy: DEFAULT_GROUP[q],
      timeField: DEFAULT_TIME[q],
      valueField: undefined,
      sortBy: undefined,
      filter: q === 'getAlerts' ? c.filter : undefined,
      columns: fieldsOf(q).slice(0, 4).map(f => f.key)
    }, 'query');
  };

  const chooseImage = (file: File | undefined) => {
    setImageError('');
    if (!file) return;
    if (!imageMimeOk(file.type)) { setImageError(describeImageError(file.name, file.type)); return; }
    if (file.size > IMAGE_MAX_BYTES) { setImageError(`“${file.name}” is ${(file.size / 1048576).toFixed(1)} MB. The limit is ${IMAGE_MAX_BYTES / 1048576} MB: make it smaller first.`); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const src = String(reader.result || '');
      if (!isImageSrc(src)) { setImageError('That file could not be used as a picture.'); return; }
      setCfg({ src }, 'image');
    };
    reader.onerror = () => setImageError('The file could not be read.');
    reader.readAsDataURL(file);
  };

  const all = fieldsOf(c.query);
  const numeric = fieldsOf(c.query, 'number');
  const times = fieldsOf(c.query, 'time');
  const metric = c.metric || 'count';
  const needsField = metric !== 'count';
  const valueFields = metric === 'distinct' ? all : numeric;
  const tile = tileDef(t);
  const native = isNative(t);
  const grouped = t === 'bar' || t === 'donut';
  const columns = c.columns || [];

  return (
    <aside className="db-inspector" aria-label="Widget settings">
      <div className="db-inspector-head">
        <h2>Settings</h2>
        <Button kind="ghost" size="sm" hasIconOnly renderIcon={Close} iconDescription="Close settings" tooltipPosition="left" onClick={onClose} />
      </div>

      <TextInput id={id('title')} labelText="Title" value={widget.title} onChange={(e: React.ChangeEvent<HTMLInputElement>) => onChange({ ...widget, title: e.target.value }, `${widget.id}:title`)} />

      <div className="cds--form-item">
        <label className="db-check">
          <input type="checkbox" checked={Boolean(c.overlay)} onChange={e => setCfg({ overlay: e.target.checked || undefined }, 'overlay')} />
          {' '}Float on top of other widgets
        </label>
        <p className="db-help">Lets this widget sit over another one (for example a logo on a dashboard). While viewing it has no frame and clicks pass through.</p>
      </div>

      {tile && (
        <p className="db-help">
          This tile is the existing “{tile.label}” panel. It fetches its own data and does not take part in cross-filtering.
          Drag the corner to give it room.
        </p>
      )}

      {t === 'text' && (
        <div className="cds--form-item">
          <label className="cds--label" htmlFor={id('text')}>Text</label>
          <textarea id={id('text')} className="db-textarea" rows={5} value={c.text || ''} onChange={e => setCfg({ text: e.target.value }, 'text')} />
        </div>
      )}

      {t === 'image' && (
        <>
          <div className="cds--form-item">
            <label className="cds--label" htmlFor={id('file')}>Picture (PNG, JPEG, GIF, WebP, SVG, BMP)</label>
            <input id={id('file')} type="file" accept={IMAGE_ACCEPT} onChange={e => { chooseImage(e.target.files ? e.target.files[0] : undefined); e.target.value = ''; }} />
          </div>
          {imageError && <p className="db-help" role="alert">{imageError}</p>}
          {c.src && <Button size="sm" kind="ghost" onClick={() => setCfg({ src: undefined }, 'image')}>Remove picture</Button>}
          <TextInput id={id('alt')} labelText="Description (alt text)" value={c.alt || ''} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCfg({ alt: e.target.value }, 'alt')} />
          <Select id={id('fit')} labelText="Fit" value={c.fit || 'contain'} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ fit: e.target.value as WidgetConfig['fit'] }, 'fit')}>
            <SelectItem value="contain" text="Whole picture (keep proportions)" />
            <SelectItem value="cover" text="Fill the box (crop edges)" />
            <SelectItem value="fill" text="Stretch to the box" />
          </Select>
        </>
      )}

      {native && t !== 'text' && t !== 'image' && (
        <>
          <h3 className="db-section">Data</h3>
          <Select id={id('query')} labelText="Source" value={c.query} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setQuery(e.target.value as QueryName)}>
            <SelectItem value="getAlerts" text="Alerts (getAlerts)" />
            <SelectItem value="getStories" text="Incidents (getStories)" />
          </Select>

          {c.query === 'getAlerts' && (
            <TextInput
              id={id('filter')}
              labelText="Alert filter (optional)"
              helperText="Sent to the server as-is. Empty means open alerts (state != 'clear'). Syntax is not checked here."
              value={c.filter || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCfg({ filter: e.target.value }, 'filter')}
            />
          )}

          <div className="db-row2">
            <Select
              id={id('wf')}
              labelText="Only rows where"
              value={c.where ? c.where.field : ''}
              onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ where: e.target.value ? { field: e.target.value, value: c.where ? c.where.value : '' } : undefined }, 'where')}
            >
              <SelectItem value="" text="(all rows)" />
              {all.filter(f => f.kind !== 'time').map(f => <SelectItem key={f.key} value={f.key} text={f.label} />)}
            </Select>
            {c.where && (
              <Select id={id('wo')} labelText="is" value={c.where.op || '='} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ where: { ...(c.where as Cond), op: e.target.value as CondOp } }, 'where')}>
                {COND_OPS.map(o => <SelectItem key={o} value={o} text={o} />)}
              </Select>
            )}
            {c.where && (
              <TextInput id={id('wv')} labelText="value" value={c.where.value} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCfg({ where: { ...(c.where as Cond), value: e.target.value } }, 'where')} />
            )}
          </div>
          {(c.also || []).map((x, i) => (
            <div className="db-row2" key={i}>
              <TextInput id={id('al' + i)} labelText={i === 0 ? 'and also' : ' '} readOnly value={`${fieldLabel(c.query, x.field)} ${x.op || '='} ${x.value}`} />
              <Button kind="ghost" size="sm" onClick={() => setCfg({ also: (c.also || []).filter((_, j) => j !== i) }, 'also')}>Remove</Button>
            </div>
          ))}

          <h3 className="db-section">Display</h3>
          {(t === 'kpi' || grouped) && (
            <>
              <Select id={id('metric')} labelText="Measure" value={metric} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ metric: e.target.value as Metric, valueField: undefined }, 'metric')}>
                {METRICS.map(m => <SelectItem key={m.v} value={m.v} text={m.t} />)}
              </Select>
              {needsField && (
                <Select id={id('vf')} labelText="Field" value={c.valueField || ''} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ valueField: e.target.value || undefined }, 'vf')}>
                  <SelectItem value="" text="Choose a field" />
                  {valueFields.map(f => <SelectItem key={f.key} value={f.key} text={f.label} />)}
                </Select>
              )}
            </>
          )}

          {grouped && (
            <>
              <Select id={id('group')} labelText="Group by" value={c.groupBy || DEFAULT_GROUP[c.query]} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ groupBy: e.target.value }, 'group')}>
                {all.filter(f => f.kind !== 'time' && f.key !== 'summary' && f.key !== 'id').map(f => <SelectItem key={f.key} value={f.key} text={f.label} />)}
              </Select>
              <TextInput id={id('limit')} labelText="Show up to (rest becomes “Other”)" type="number" min={2} max={30} value={String(c.limit || 8)} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCfg({ limit: Math.min(Math.max(Number(e.target.value) || 8, 2), 30) }, 'limit')} />
            </>
          )}

          {t === 'timeseries' && (
            <Select id={id('time')} labelText="Time field" value={c.timeField || DEFAULT_TIME[c.query]} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ timeField: e.target.value }, 'time')}>
              {times.map(f => <SelectItem key={f.key} value={f.key} text={f.label} />)}
            </Select>
          )}

          {t === 'table' && (
            <>
              <fieldset className="db-checks">
                <legend className="cds--label">Columns</legend>
                {all.map(f => (
                  <Checkbox
                    key={f.key}
                    id={id(`col-${f.key}`)}
                    labelText={f.label}
                    checked={columns.includes(f.key)}
                    onChange={(_: unknown, state: { checked: boolean }) => {
                      const next = state.checked ? all.map(a => a.key).filter(k => columns.includes(k) || k === f.key) : columns.filter(k => k !== f.key);
                      setCfg({ columns: next }, 'columns');
                    }}
                  />
                ))}
              </fieldset>
              <TextInput id={id('rows')} labelText="Rows to show" type="number" min={5} max={500} value={String(c.limit || 50)} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCfg({ limit: Math.min(Math.max(Number(e.target.value) || 50, 5), 500) }, 'rows')} />
            </>
          )}

          <h3 className="db-section">Refresh</h3>
          <Select id={id('refresh')} labelText="Reload data" value={String(c.refreshSeconds || 0)} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCfg({ refreshSeconds: Number(e.target.value) }, 'refresh')}>
            {REFRESH.map(r => <SelectItem key={r.v} value={String(r.v)} text={r.t} />)}
          </Select>

          <h3 className="db-section">Linking</h3>
          {grouped && (
            <Toggle
              id={id('emits')}
              size="sm"
              labelText="Click sets a filter"
              labelA="Off"
              labelB="On"
              toggled={c.emits !== false}
              onToggle={(on: boolean) => setCfg({ emits: on }, 'emits')}
            />
          )}
          <Toggle
            id={id('listens')}
            size="sm"
            labelText="Follows filters from other widgets"
            labelA="Off"
            labelB="On"
            toggled={c.listens !== false}
            onToggle={(on: boolean) => setCfg({ listens: on }, 'listens')}
          />
          <p className="db-help">Linking works between widgets that use the same source (alerts with alerts, incidents with incidents).</p>
        </>
      )}
    </aside>
  );
}
