/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 *
 * The drag-and-resize surface. 12 columns, fixed row height. While editing, drag a widget by its title bar,
 * resize from the corner, or use the keyboard (arrows move, Shift+arrows resize, Delete removes).
 * The layout is only handed to the parent when a drag ends, so the rest of the page does not re-render per pixel.
 */

import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Button } from '@carbon/react';
import { Copy, Settings, TrashCan } from '@carbon/icons-react';
import { moveItem, resizeItem, gridHeight } from './grid';
import { GRID_COLS, Widget } from './types';
import { minSize } from './registry';

const ROW_H = 48;
const GAP = 10;
const NARROW = 640;

interface Props {
  widgets: Widget[];
  rowH?: number;
  editing: boolean;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onLayout: (next: Widget[], label: string) => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
  renderBody: (w: Widget) => React.ReactNode;
}

type Gesture =
  | { kind: 'move'; id: string; px: number; py: number; x: number; y: number }
  | { kind: 'resize'; id: string; px: number; py: number; w: number; h: number };

export default function GridCanvas({ widgets, rowH, editing, selectedId, onSelect, onLayout, onRemove, onDuplicate, renderBody }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(960);
  // While a gesture is running the preview layout lives here; it is committed on pointer-up.
  const [preview, setPreview] = useState<Widget[] | null>(null);
  const previewRef = useRef<Widget[] | null>(null);
  const gestureRef = useRef<Gesture | null>(null);
  const dragging = preview !== null;

  useLayoutEffect(() => {
    const el = wrapRef.current;
    if (el && el.clientWidth > 0) setWidth(el.clientWidth);
  }, []);
  useEffect(() => {
    const el = wrapRef.current;
    if (!el || typeof ResizeObserver === 'undefined') return undefined;
    const obs = new ResizeObserver(entries => {
      const w = entries[0].contentRect.width;
      if (w > 0) setWidth(Math.round(w));
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const colW = Math.max((width - GAP * (GRID_COLS - 1)) / GRID_COLS, 20);
  const stepX = colW + GAP;
  const ROW = rowH && rowH >= 24 && rowH <= 96 ? rowH : ROW_H;
  const stepY = ROW + GAP;
  const items = preview || widgets;
  const narrow = width < NARROW && !editing;

  const begin = (e: React.PointerEvent, g: Gesture) => {
    if (!editing || e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    onSelect(g.id);
    gestureRef.current = g;
    previewRef.current = widgets;
    setPreview(widgets);
    const onMove = (ev: PointerEvent) => {
      const cur = gestureRef.current;
      if (!cur) return;
      const dx = Math.round((ev.clientX - cur.px) / stepX);
      const dy = Math.round((ev.clientY - cur.py) / stepY);
      const next = cur.kind === 'move'
        ? moveItem(widgets, cur.id, cur.x + dx, cur.y + dy)
        : resizeItem(widgets, cur.id, cur.w + dx, cur.h + dy, minSize(widgets.find(w => w.id === cur.id)!.type).minW, minSize(widgets.find(w => w.id === cur.id)!.type).minH);
      previewRef.current = next;
      setPreview(next);
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      const cur = gestureRef.current;
      const result = previewRef.current;
      gestureRef.current = null;
      previewRef.current = null;
      setPreview(null);
      if (cur && result && result !== widgets && result.some((r, i) => {
        const o = widgets[i];
        return r.x !== o.x || r.y !== o.y || r.w !== o.w || r.h !== o.h;
      })) {
        onLayout(result, cur.kind === 'move' ? 'Move widget' : 'Resize widget');
      }
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  };

  const onKey = (e: React.KeyboardEvent, w: Widget) => {
    if (!editing || e.target !== e.currentTarget) return;
    const d: Record<string, [number, number]> = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    if (e.key === 'Delete' || e.key === 'Backspace') {
      e.preventDefault();
      onRemove(w.id);
    } else if (d[e.key]) {
      e.preventDefault();
      const [dx, dy] = d[e.key];
      const { minW, minH } = minSize(w.type);
      onLayout(e.shiftKey ? resizeItem(widgets, w.id, w.w + dx, w.h + dy, minW, minH) : moveItem(widgets, w.id, w.x + dx, w.y + dy), e.shiftKey ? 'Resize widget' : 'Move widget');
    } else if (e.key === 'Escape') {
      onSelect(null);
    }
  };

  const ordered = narrow ? items.slice().sort((a, b) => a.y - b.y || a.x - b.x) : items;
  const height = narrow ? undefined : (gridHeight(items) + (editing ? 3 : 0)) * stepY;

  return (
    <div
      ref={wrapRef}
      className={`db-canvas${editing ? ' editing' : ''}${dragging ? ' dragging' : ''}${narrow ? ' narrow' : ''}`}
      style={{ height }}
      onPointerDown={e => { if (e.target === e.currentTarget) onSelect(null); }}
    >
      {widgets.length === 0 && (
        <div className="db-canvas-empty">
          <strong>This dashboard is empty.</strong>
          <span>{editing ? 'Use “Add widget” to place your first one.' : 'Switch to Edit to add widgets.'}</span>
        </div>
      )}
      {ordered.map(w => {
        const style: React.CSSProperties = narrow
          ? { height: Math.max(w.h, 3) * stepY - GAP }
          : { left: w.x * stepX, top: w.y * stepY, width: w.w * colW + (w.w - 1) * GAP, height: w.h * ROW + (w.h - 1) * GAP, ...(w.config.overlay ? { zIndex: 8 } : {}) };
        const active = gestureRef.current && gestureRef.current.id === w.id;
        return (
          <section
            key={w.id}
            className={`db-widget${selectedId === w.id && editing ? ' selected' : ''}${active ? ' active' : ''}${w.config.chromeless || w.config.overlay ? ' db-chromeless' : ''}${w.config.overlay ? ' db-overlay' : ''}`}
            style={style}
            tabIndex={editing ? 0 : -1}
            aria-label={`${w.title} widget`}
            onKeyDown={e => onKey(e, w)}
            onPointerDown={() => { if (editing) onSelect(w.id); }}
          >
            <header
              className="db-widget-head"
              onPointerDown={e => begin(e, { kind: 'move', id: w.id, px: e.clientX, py: e.clientY, x: w.x, y: w.y })}
              title={editing ? 'Drag to move' : undefined}
            >
              <h3>{w.title}</h3>
              {editing && (
                <div className="db-widget-actions" onPointerDown={e => e.stopPropagation()}>
                  <Button kind="ghost" size="sm" hasIconOnly renderIcon={Settings} iconDescription="Settings" tooltipPosition="bottom" onClick={() => onSelect(w.id)} />
                  <Button kind="ghost" size="sm" hasIconOnly renderIcon={Copy} iconDescription="Duplicate" tooltipPosition="bottom" onClick={() => onDuplicate(w.id)} />
                  <Button kind="ghost" size="sm" hasIconOnly renderIcon={TrashCan} iconDescription="Remove" tooltipPosition="bottom" onClick={() => onRemove(w.id)} />
                </div>
              )}
            </header>
            <div className="db-widget-body">{renderBody(w)}</div>
            {editing && !narrow && (
              <div
                className="db-resize"
                role="presentation"
                title="Drag to resize"
                onPointerDown={e => begin(e, { kind: 'resize', id: w.id, px: e.clientX, py: e.clientY, w: w.w, h: w.h })}
              />
            )}
          </section>
        );
      })}
    </div>
  );
}
