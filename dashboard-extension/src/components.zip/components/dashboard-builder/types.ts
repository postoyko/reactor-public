/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 */

export const GRID_COLS = 12;

export type QueryName = 'getAlerts' | 'getStories';
export type Row = Record<string, string | number | undefined>;

export type NativeType = 'kpi' | 'bar' | 'donut' | 'timeseries' | 'table' | 'text' | 'image';
/** A tile embeds one of the toolkit's existing panels as it is (it fetches its own data and does not cross-filter). */
export type WidgetType = NativeType | `tile:${string}`;

/** `op` defaults to '='. Comparisons are numeric when both sides are numbers. */
export type CondOp = '=' | '!=' | '<' | '<=' | '>' | '>=';
export interface Cond { field: string; value: string; op?: CondOp }
export const COND_OPS: CondOp[] = ['=', '!=', '<', '<=', '>', '>='];

export type Metric = 'count' | 'distinct' | 'max' | 'avg' | 'sum';

export interface WidgetConfig {
  query: QueryName;
  /** Server-side filter (alerts only), e.g. severity >= 5. Empty means the default (state != 'clear'). */
  filter?: string;
  /** Fixed client-side condition: only rows where `field` equals `value` are used. */
  where?: Cond;
  /** More conditions, all of which must hold (AND). */
  also?: Cond[];
  groupBy?: string;
  metric?: Metric;
  valueField?: string;
  timeField?: string;
  columns?: string[];
  limit?: number;
  sortBy?: string;
  sortDesc?: boolean;
  refreshSeconds?: number;
  /** Clicking a bar / slice sets a filter that other widgets on the same query can follow. */
  emits?: boolean;
  /** Follow the filters set by other widgets on the same query. */
  listens?: boolean;
  text?: string;
  /** Tiles only: what this tile stands in for when a dashboard was split into widgets (shown in Scaffold Studio). */
  part?: string;
  /** Tiles only: while viewing, show no frame and no title bar (the embedded panel has its own heading). Editing still shows them. */
  chromeless?: boolean;
  /** Tiles only: options passed to the embedded panel as props (for example { part: 'services' } shows one section of a dashboard that supports it). */
  props?: Record<string, string | number | boolean>;
  /** Float on top of the grid: ignores collisions and gap-closing, so it can sit over another widget (for example a logo on a dashboard tile). */
  overlay?: boolean;
  /** Image widgets: the picture as a data URI (see image.ts). */
  src?: string;
  alt?: string;
  fit?: 'contain' | 'cover' | 'fill';
}

export interface Widget {
  id: string;
  type: WidgetType;
  title: string;
  x: number;
  y: number;
  w: number;
  h: number;
  config: WidgetConfig;
}

export interface Dashboard {
  id: string;
  name: string;
  updated: number;
  widgets: Widget[];
  /** Row height in pixels (24 to 96, default 48). */
  rowH?: number;
}

export interface Filter {
  /** Widget that set it (it highlights instead of filtering itself). */
  from: string;
  query: QueryName;
  field: string;
  value: string;
}

export interface Box {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
}
