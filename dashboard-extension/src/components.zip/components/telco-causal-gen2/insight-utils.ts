/**
 * © Copyright IBM Corp. 2022, 2026
 * SPDX-License-Identifier: Apache-2.0
 *
 * Colours shared by the insight views so a severity or a tier looks the same everywhere.
 */

import { LAYER_BY_ID } from './classification';

/** Same severity scale as the 3D lens (6 critical ... 3 warning, below that healthy/informational). */
export const severityHex = (severity: number): string => {
  if (severity >= 6) return '#da1e28';
  if (severity === 5) return '#ba4e00';
  if (severity === 4) return '#b28600';
  if (severity === 3) return '#0f62fe';
  return '#198038';
};

export const SEVERITY_LABEL = (severity: number): string => {
  if (severity >= 6) return 'Critical';
  if (severity === 5) return 'Major';
  if (severity === 4) return 'Minor';
  if (severity === 3) return 'Warning';
  return 'Info / clear';
};

/** Tier accent colours (match the strata colours of the 3D scene). */
export const TIER_HEX: Record<number, string> = Object.fromEntries(Object.values(LAYER_BY_ID).map(l => [l.id, l.color]));

export const formatTime = (ms: number): string => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
export const formatDateTime = (ms: number): string => new Date(ms).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });

/** Soft fills for the area charts (sunburst / treemap): readable dark text on top, big blocks stay calm. */
export const severityPastel = (severity: number): string => {
  if (severity >= 6) return '#f5b1b4';
  if (severity === 5) return '#f8cba8';
  if (severity === 4) return '#f4e3a1';
  if (severity === 3) return '#b4d0fb';
  return '#b3e0bf';
};

/** Slightly deeper edge colour matching severityPastel, for group outlines. */
export const severityPastelEdge = (severity: number): string => {
  if (severity >= 6) return '#e48a8f';
  if (severity === 5) return '#e6a97c';
  if (severity === 4) return '#dcc673';
  if (severity === 3) return '#8bb2f0';
  return '#86c796';
};
